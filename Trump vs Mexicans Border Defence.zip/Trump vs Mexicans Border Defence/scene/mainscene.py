import pygame
from .scene import Scene
from gameobject.arrow import Arrow


class MainScene(Scene):
    def update(self, rabbit, arrows, badgers):
        screen = self.game.screen
        sound = self.game.sound

        badgers.update(self.game)
        arrows.update(screen.get_size())
        Arrow.check_shot(arrows, badgers, sound['shotEnemy'])
        rabbit.update()

    def draw(self, rabbit, arrows, badgers):
        screen = self.game.screen

        self.draw_background()
        self.draw_gamedata()
        rabbit.draw(screen)
        badgers.draw(screen)
        arrows.draw(screen)

        pygame.display.flip()

    def draw_background(self):
        game = self.game
        screen = game.screen

        img_grass = game.image['grass']
        grass_w, grass_h = img_grass.get_size()
        screen_w, screen_h = screen.get_size()
        x_range = int(screen_w/grass_w) + 1
        y_range = int(screen_h/grass_h) + 1

        for x in range(x_range):
            for y in range(y_range):
                screen.blit(img_grass, (x*grass_w, y*grass_h))

        img_castle = game.image['castle']
        h_castle = img_castle.get_height()
        dh = (screen_h - h_castle * 4) / 5
        y_castle = [
            dh,
            dh * 2 + h_castle,
            dh * 3 + h_castle * 2,
            dh * 4 + h_castle * 3,
        ]
        for y in y_castle:
            screen.blit(img_castle, (0, y))

    def draw_gamedata(self):
        game = self.game
        time_left = game.time_limit - pygame.time.get_ticks()
        if time_left < 0:
            time_left = 0

        font_size = 32
        color = (248, 245, 228)
        font = pygame.font.Font(None, font_size)
        text = font.render(
            'Time Left   {} : {}'.format(
                str(int(time_left/60000)),
                str(int(time_left/1000) % 60).zfill(2)
                ),
            True,
            color,
        )

        screen = game.screen
        width = screen.get_width()
        rect = pygame.Rect(width - 185, 10, 175, 25)
        screen.blit(text, rect)

        img_lifebar = game.image['lifebar']
        left = width - img_lifebar.get_width()-5
        top = 47
        screen.blit(img_lifebar, (left, top))

        bias = 2
        x = bias + left
        img = game.image['life_counter']
        for i in range(game.life):
            screen.blit(img, (i + x, bias + 47))
