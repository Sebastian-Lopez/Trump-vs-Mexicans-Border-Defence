import pygame
from .scene import Scene
from gameobject.arrow import Arrow


class EndScene(Scene):
    def draw(self):
        game = self.game
        screen = game.screen

        if game.win:
            img = game.image['youwin']
        else:
            img = game.image['gameover']
        screen.blit(img, (0, 0))

        font = pygame.font.Font(None, 24)
        color = (248, 245, 228)
        fired = Arrow.get_fired_num()
        shot = Arrow.get_shot_num()
        accuracy = Arrow.get_accuracy()

        if fired > 1:
            s1 = 'arrows'
        else:
            s1 = 'arrow'
        if shot > 1:
            s2 = 'enemies'
        else:
            s2 = 'enemy'
        text_list = [
            font.render('You fired  {} {},  shot  {}  {}.'.format(fired, s1, shot, s2), True, color),
            font.render('Accuracy:  {:.2f}%'.format(accuracy), True, color),
        ]

        dy = 30
        for text in text_list:
            rect = text.get_rect()
            cx, cy = screen.get_rect().center
            rect.center = cx, cy + dy
            screen.blit(text, rect)
            dy += rect.height + 10

        pygame.display.flip()
