class Scene:
    def __init__(self, game):
        self.game = game

    def draw(self, *args):
        raise NotImplementedError
