import pygame
import random


class Badger(pygame.sprite.Sprite):
    def __init__(self, image, screen_size):
        pygame.sprite.Sprite.__init__(self)

        x = screen_size[0]
        y = random.randint(35, screen_size[1]-50)
        self.position = [x, y]

        self.speed = random.randint(4, 7)
        self.image = image
        self.rect = self.image.get_rect(topleft=self.position)
        self.mask = pygame.mask.from_surface(self.image)

    def update(self, game):
        sound = game.sound['explodeCastle']
        if self.position[0] < 64:
            sound.play()
            # the slower the badger moves, the more the player's life decreases
            game.life -= 14 - self.speed
            self.kill()
        else:
            self.position[0] -= self.speed
            self.rect.left = self.position[0]
