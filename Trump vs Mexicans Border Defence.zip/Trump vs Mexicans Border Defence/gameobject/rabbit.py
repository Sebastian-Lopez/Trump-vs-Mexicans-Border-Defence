import math
import pygame
from game.game import Game


class Rabbit(pygame.sprite.Sprite):
    def __init__(self, game, center, speed):
        pygame.sprite.Sprite.__init__(self)
        self.raw_image = game.image['rabbit']
        self.degrees = 0
        self.center = center
        self.speed = speed
        self.image = self.raw_image
        self.rect = self.image.get_rect(center=center)
        self.game = game

    def update(self):
        a = Game.get_angle(pygame.mouse.get_pos(), self.center)
        self.degrees = math.degrees(a)
        self.image = pygame.transform.rotate(self.raw_image, -self.degrees)
        self.rect = self.image.get_rect(center=self.center)

    def move_up(self):
        y = self.center[1]
        half_h = self.rect.height/2

        y -= self.speed
        if y - half_h <= 0:
            y = half_h

        self.center[1] = y

    def move_down(self):
        y = self.center[1]
        screen_h = self.game.screen.get_height()
        half_h = self.rect.height/2

        y += self.speed
        if y + half_h >= screen_h:
            y = screen_h - half_h

        self.center[1] = y

    def move_left(self):
        x = self.center[0]
        half_w = self.rect.width/2

        x -= self.speed
        if x - half_w <= 0:
            x = half_w

        self.center[0] = x

    def move_right(self):
        x = self.center[0]
        screen_w = self.game.screen.get_width()
        half_w = self.rect.width/2

        x += self.speed
        if x + half_w >= screen_w:
            x = screen_w - half_w

        self.center[0] = x

    def draw(self, screen):
        screen.blit(self.image, self.rect)
