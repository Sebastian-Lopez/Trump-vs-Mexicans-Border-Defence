import pygame
import random
import math
from game.game import Game


class Arrow(pygame.sprite.Sprite):
    __fired_num = 0
    __shot_num = 0

    def __init__(self, game, center):
        pygame.sprite.Sprite.__init__(self)
        self.speed = random.randint(37, 38)
        self.center = center
        self.angle = Game.get_angle(pygame.mouse.get_pos(), center)
        self.image = pygame.transform.rotate(game.image['arrow'], math.degrees(-self.angle))
        self.rect = self.image.get_rect(center=center)
        self.mask = pygame.mask.from_surface(self.image)
        self.__class__.__fired_num += 1
        game.sound['fire'].play()

    def update(self, screen_size):
        x, y = self.center
        screen_w, screen_h = screen_size
        vx = math.cos(self.angle)*self.speed
        vy = math.sin(self.angle)*self.speed

        x += vx
        y += vy
        if x < 0 or x > screen_w or y < 0 or y > screen_h:
            self.kill()
        else:
            self.center = [x, y]
            self.rect.center = self.center

    @classmethod
    def check_shot(cls, arrows, badgers, sound):
        collide_dict = pygame.sprite.groupcollide(arrows, badgers, True, True, pygame.sprite.collide_mask)
        num = collide_dict.__len__()
        if num:
            cls.__shot_num += num
            sound.play()

    @classmethod
    def get_accuracy(cls):
        if cls.__fired_num:
            accuracy = cls.__shot_num/cls.__fired_num*100
        else:
            accuracy = 0

        return accuracy

    @classmethod
    def get_fired_num(cls):
        return cls.__fired_num

    @classmethod
    def get_shot_num(cls):
        return cls.__shot_num
