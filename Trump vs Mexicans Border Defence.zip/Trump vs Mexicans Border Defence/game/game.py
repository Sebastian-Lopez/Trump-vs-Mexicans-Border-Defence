import pygame
import math
import os


class Game:
    def __init__(self, name, screen_size=(715, 450), time_limit=60000, life=196):
        pygame.init()
        pygame.mouse.set_cursor(*pygame.cursors.broken_x)
        pygame.display.set_caption(name)

        self.running = True
        self.win = False
        self.screen = pygame.display.set_mode(screen_size)
        self.sound = self.__class__.set_music()
        self.image = self.__class__.load_image()
        self.actions = {}
        self.keys_down = {}
        self.event_registered = []
        self.life = life
        self.time_limit = time_limit

    def register_action(self, key, function):
        self.keys_down[key] = False
        self.actions[key] = function

    def register_event(self, event_type, function):
        self.event_registered.append(event_type)
        self.actions[event_type] = function

    def perform_action(self):
        for k in self.keys_down:
            if self.keys_down[k]:
                self.actions[k]()

    @staticmethod
    def get_angle(point, center_point):
        dx = point[0] - center_point[0]
        dy = point[1] - center_point[1]
        angle = math.atan2(dy, dx)
        return angle

    @staticmethod
    def set_music():
        path = 'resources/audio'
        sound_name = ['explodeCastle', 'shotEnemy', 'fire', ]
        sound = {i: pygame.mixer.Sound(os.path.join(path, '{}.wav'.format(i))) for i in sound_name}

        for s in sound.values():
            s.set_volume(0.05)

        bgm = pygame.mixer.music
        bgm.load(os.path.join(path, 'moonlight.mp3'))
        bgm.play(-1)
        bgm.set_volume(0.50)
        return sound

    @staticmethod
    def load_image():
        path = 'resources/images'
        img_name = ['grass', 'castle', 'gameover', 'youwin', 'lifebar', 'life_counter', 'arrow', 'rabbit', 'badger', ]

        image = {i: pygame.image.load(os.path.join(path, '{}.png'.format(i))) for i in img_name}

        return image

    @staticmethod
    def hold():
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    Game.quit_game()

    @staticmethod
    def quit_game():
        pygame.quit()
        exit(0)

    def end_game(self):
        self.running = False

    def win_game(self):
        self.win = True

    def time_up(self):
        return pygame.time.get_ticks() >= self.time_limit

    def dead(self):
        return self.life <= 0

    def run(self):
        for event in pygame.event.get():
            if event.type in self.event_registered:
                self.actions[event.type]()

            elif event.type == pygame.KEYDOWN:
                if event.key in self.keys_down:
                    self.keys_down[event.key] = True

            elif event.type == pygame.KEYUP:
                if event.key in self.keys_down:
                    self.keys_down[event.key] = False

        if self.dead():
            self.end_game()

        elif self.time_up():
            self.end_game()
            self.win_game()

        else:
            self.perform_action()
