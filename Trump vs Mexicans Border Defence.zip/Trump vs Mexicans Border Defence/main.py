import pygame
from game.game import Game
from scene.mainscene import MainScene
from scene.endscene import EndScene
from gameobject.rabbit import Rabbit
from gameobject.arrow import Arrow
from gameobject.badger import Badger


def __main():
    game = Game('Trump vs Mexicans: Border Defence')
    scene = MainScene(game)
    rabbit = Rabbit(game, [100, 100], 5)
    badgers = pygame.sprite.Group()
    arrows = pygame.sprite.Group()

    def add_arrow():
        arrows.add(Arrow(game, rabbit.center))

    game.register_event(pygame.QUIT, Game.quit_game)
    game.register_event(pygame.MOUSEBUTTONDOWN, add_arrow)
    game.register_action(pygame.K_w, rabbit.move_up)
    game.register_action(pygame.K_s, rabbit.move_down)
    game.register_action(pygame.K_a, rabbit.move_left)
    game.register_action(pygame.K_d, rabbit.move_right)

    timer = 100
    max_timer = 100

    while game.running:
        game.run()
        timer -= 1
        if timer == 0:
            badgers.add(Badger(game.image['badger'], game.screen.get_size()))
            timer = max_timer
            if max_timer >= 10:
                max_timer -= 1

        scene.update(rabbit, arrows, badgers)
        scene.draw(rabbit, arrows, badgers)

    end_scene = EndScene(game)
    end_scene.draw()

    Game.hold()


__main()
